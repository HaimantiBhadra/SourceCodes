using MCCustomerService.Controllers;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.Extensions.Configuration;
using NUnit.Framework;
using System.Collections.Generic;

namespace NUnitCustomerServiceTest
{
    public class KYCUploadTest
    {
        private KYCUploadController kYCUploadController;
        public IConfiguration Configuration { get; set; }

        [SetUp]
        public void SetUp()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
            KeyValuePair<string, string> keyValuePair1 = new KeyValuePair<string, string>("AWSBucketName", "hbhadrasample1");
            List<KeyValuePair<string, string>> keyValuePairs = new List<KeyValuePair<string, string>>();
            keyValuePairs.Add(keyValuePair1);
            keyValuePair1=  new KeyValuePair<string, string>("AWSServiceURL", "https://s3.us-east-2.amazonaws.com/");
            keyValuePairs.Add(keyValuePair1);
            // Duplicate here any configuration sources you use.
            configurationBuilder.AddInMemoryCollection(keyValuePairs);

            Configuration = configurationBuilder.Build();
            kYCUploadController = new KYCUploadController(Configuration);
        }

        [Test]
        public void UploadFile_NegativeTest()
        {
            string filePath = @"C:\Users\HP\Desktop\1_AccountStatement.csv";
            var result = kYCUploadController.UploadFile(filePath);
            //Assert.Pass();
            Assert.IsFalse(result.Value.Equals("File Uploaded Successfully!!"), "UploadFile Not Successful");
        }

        [Test]
        public void UploadFile_PositiveTest()
        {
            string filePath = @"C:\Users\HP\Desktop\1_AccountStatement.csv";
            var result = kYCUploadController.UploadFile(filePath);
            Assert.Pass();           
        }
    }
}