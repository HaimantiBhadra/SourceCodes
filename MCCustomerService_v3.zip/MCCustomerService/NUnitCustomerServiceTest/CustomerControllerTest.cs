﻿using MCCustomerService.Controllers;
using MCCustomerService.Repository;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.Extensions.Configuration;
using NUnit.Framework;
using System.Collections.Generic;

namespace NUnitCustomerServiceTest
{
    public class CustomerControllerTest
    {
        private CustomersController customersController;
        public ICustomerServiceRepository Configuration { get; set; }

        [SetUp]
        public void SetUp()
        {
            ICustomerServiceRepository customerServiceRepository = new CustomerServiceRepository(null);
            customersController = new CustomersController(Configuration);
        }

        [Test]
        public void UploadFile_NegativeTest()
        {
            string filePath = @"C:\Users\HP\Desktop\1_AccountStatement.csv";
            var result = customersController.UploadFile(filePath);
            //Assert.Pass();
            Assert.IsFalse(result.Value.Equals("File Uploaded Successfully!!"), "UploadFile Not Successful");
        }

        [Test]
        public void UploadFile_PositiveTest()
        {
            string filePath = @"C:\Users\HP\Desktop\1_AccountStatement.csv";
            var result = customersController.UploadFile(filePath);
            Assert.Pass();
        }
    }
}
