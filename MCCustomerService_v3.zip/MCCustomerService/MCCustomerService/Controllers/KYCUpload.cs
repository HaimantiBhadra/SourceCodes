﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace MCCustomerService.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class KYCUploadController : ControllerBase
    {

        private IConfiguration Configuration;
        public KYCUploadController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        [Route("api/uploadFile")]
        [HttpPost]
        public ActionResult<string> UploadFile(string filePath)
        {
            string Message;
            // Specify your bucket region (an example region is shown).  
            string bucketName = Configuration.GetValue<string>("AWSBucketName");
            string serviceUrl = Configuration.GetValue<string>("AWSServiceURL");
            
            AmazonS3Config aWSConfigsS3 = new AmazonS3Config();
            aWSConfigsS3.ServiceURL = string.Concat(serviceUrl, bucketName);
            
            var s3Client = new AmazonS3Client(aWSConfigsS3);

            var fileTransferUtility = new TransferUtility(s3Client);
            try
            {
                if (filePath.Length > 0)
                {
                    fileTransferUtility.Upload(filePath, bucketName);
                    fileTransferUtility.Dispose();
                }
                Message = "File Uploaded Successfully!!";
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                if (amazonS3Exception.ErrorCode != null &&
                    (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId")
                    ||
                    amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                {
                    Message = "Check the provided AWS Credentials.";
                }
                else
                {
                    Message = "Error occurred: " + amazonS3Exception.Message;
                }
            }
            catch(Exception ex)
            {
                Message = "Exception occurred: " + ex.Message;
            }
            return Message;
        }
    }
}
