﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MCCustomerService.Data;
using MCCustomerService.Models;
using MCCustomerService.Repository;

namespace MCCustomerService.Controllers
{
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        //private readonly CustomerServiceContext _context;

        /*public CustomersController(CustomerServiceContext context)
        {
            _context = context;
        }*/

        private readonly ICustomerServiceRepository customerServicerepository;
        public CustomersController(ICustomerServiceRepository customerRepository)
        {
            customerServicerepository = customerRepository;
        }



        [HttpGet(Name = "CheckCustomer")]
        [Route("api/get")]
        public ActionResult<Customer> RetriveCustomer(int customerId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                Customer customer = customerServicerepository.RetreiveCustomer(customerId);
                return customer;
                //return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            { return BadRequest(ex.Message); }
            //return CreatedAtAction("GetCustomer", new { id = customer.ID }, customer);
        }


        [HttpPost(Name = "AddCustomer")]
        [Route("api/add")]
        public ActionResult<Customer> AddCustomer(Customer customer)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                customerServicerepository.AddCustomer(customer);
                return  customer;
                //return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            { return BadRequest(ex.Message); }
            //return CreatedAtAction("GetCustomer", new { id = customer.ID }, customer);
        }

        [HttpPost(Name = "UpdateCustomer")]
        [Route("api/update")]
        public ActionResult<Customer> UpdateCustomer(Customer customer)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                customerServicerepository.UpdateCustomer(customer);
                return customer;
                //return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            { return BadRequest(ex.Message); }
            //return CreatedAtAction("GetCustomer", new { id = customer.ID }, customer);
        }


        
    }
}