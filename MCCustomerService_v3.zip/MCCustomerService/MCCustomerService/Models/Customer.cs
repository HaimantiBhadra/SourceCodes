﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MCCustomerService.Models
{
    
    //[Table("BMS_Users")]
    public class Customer
    {
        public int ID { get; set; }
        public string UserName { get; set; }
        public string UserPassword { get; set; }
        public string Email { get; set; }
        public string PAN { get; set; }
        public string UserAddress { get; set; }
        public DateTime DOB { get; set; }
    }
}
