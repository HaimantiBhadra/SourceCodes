﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MCAccountService.Data
{
    public class DBInitializer
    {
        public static void Initialize(AccountServiceContext context)
        {
            context.Database.EnsureCreated();

            if(context.Accounts.Any())
            {
                return;
            }

            //context.Accounts.Add()
        }
    }
}
