﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MCAccountService.Models
{
    public class LoanDetails
    {
        [Key]
        public int LoanId { get; set; }
        public int AccountId { get; set; }
        public string LoanType { get; set; }
        public DateTime LoanStartDate { get; set; }
        public int LoanDurationMonth { get; set; }
        public decimal LoanAmount { get; set; }
        public decimal ROI { get; set; }
        public int CustomerId { get; set; }
    }
}
