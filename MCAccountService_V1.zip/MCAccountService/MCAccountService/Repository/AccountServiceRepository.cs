﻿using MCAccountService.Common;
using MCAccountService.Data;
using MCAccountService.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MCAccountService.Repository
{
    public class AccountServiceRepository : IAccountServiceRepository
    {
        private AccountServiceContext accountDbContext;
        public AccountServiceRepository(AccountServiceContext _accountDbContext)
        {
            accountDbContext = _accountDbContext;
        }

        public Accounts RetreiveAccount(int accountId, int customerId)
        {
            var cust = accountDbContext.Accounts.SingleOrDefault(m => m.AccountId == accountId
                                                                    & m.CustomerId == customerId);
            return cust;
        }
        public void AddAccounts(Accounts Accounts)
        {
            accountDbContext.Accounts.Add(Accounts);
            accountDbContext.SaveChanges(true);
        }

        public void UpdateAccounts(Accounts Accounts)
        {
            accountDbContext.Accounts.Update(Accounts);
            accountDbContext.SaveChanges(true);
        }


        public void ApplyLoan(LoanDetails loanDetails)
        {
            Accounts accounts = new Accounts();
            accounts.AccountType = "LoanAccount";
            accounts.AccountOpeningDate = DateTime.Now;
            accounts.CustomerId = loanDetails.CustomerId;


            AddAccounts(accounts);
            loanDetails.AccountId = accounts.AccountId;
            accountDbContext.AccountLoans.Add(loanDetails);
            accountDbContext.SaveChanges(true);
        }

        public Byte[] DownloadAccountStatemenmt(int customerId)
        {
            var report = accountDbContext.Accounts.Where(x => x.CustomerId == customerId);
            if (report == null)
            {
                return null;
            }

            DataTable dt = Common.Utility.ToDataTable(report);

            return Common.Utility.WriteCSVSimple(dt);
        }

    }
}
