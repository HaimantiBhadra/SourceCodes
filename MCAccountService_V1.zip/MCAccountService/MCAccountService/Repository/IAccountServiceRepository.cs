﻿using MCAccountService.Models;
using System;
using System.Collections.Generic;

namespace MCAccountService.Repository
{
    public interface IAccountServiceRepository
    {
        Accounts RetreiveAccount(int accountId, int customerId);
        void AddAccounts(Accounts Accounts);
        void UpdateAccounts(Accounts Accounts);
        void ApplyLoan(LoanDetails loanDetails);
        Byte[] DownloadAccountStatemenmt(int customerId);

    }
}