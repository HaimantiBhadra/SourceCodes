﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MCCustomerService.Models;

namespace MCCustomerService.Data
{
    public class CustomerServiceContext : DbContext
    {
        public CustomerServiceContext (DbContextOptions<CustomerServiceContext> options)
            : base(options)
        {
        }

        public DbSet<Customer> Customer { get; set; }

    }
}
