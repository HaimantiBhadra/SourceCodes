using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleLambda
{
    public class Blog
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Content { get; set; }
        public DateTime CreatedTimestamp { get; set; }
    }

    
    public class UserLogin
    {
        [DynamoDBHashKey]
        public string UserId { get; set; }
        public string Password { get; set; }

    }
}
