﻿using MCCustomerService.Controllers;
using MCCustomerService.Data;
using MCCustomerService.Models;
using MCCustomerService.Repository;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System;
using System.Collections.Generic;


namespace NUnitCustomerServiceTest
{
    public class CustomerControllerTest
    {
        private CustomersController customersController;
        public ICustomerServiceRepository Configuration { get; set; }

        //private readonly CustomerServiceContext _context;

        //public CustomerControllerTest(CustomerServiceContext context)
        //{
        //    _context = context;
        //}


        [SetUp]
        public void SetUp()
        {
           // var opt = new SQLServerDBContextOptionsBUilder().UseSqlServer();
            
            ICustomerServiceRepository customerServiceRepository = new CustomerServiceRepository(null);
            customersController = new CustomersController(Configuration);
        }

        //[Test]
        //public void UploadFile_NegativeTest()
        //{
        //    string filePath = @"C:\Users\HP\Desktop\1_AccountStatement.csv";
        //    var result = customersController.UploadFile(filePath);
        //    //Assert.Pass();
        //    Assert.IsFalse(result.Value.Equals("File Uploaded Successfully!!"), "UploadFile Not Successful");
        //}

        [Test]
        public void AddCustomerNegativeTest()
        {
            Customer customer = new Customer()
            {
                UserName = "MC Customer 1",
                UserPassword = "Password",
                Email = "test@gmail.com",
                PAN = "ABCD",
                UserAddress = "201 st rock, USA",
                DOB = DateTime.Parse("06-07-1987")
            };
            var result = customersController.AddCustomer(customer);
            Assert.IsTrue(result.Value == null, "Customer Not Added");
            
        }

        
    }
}
