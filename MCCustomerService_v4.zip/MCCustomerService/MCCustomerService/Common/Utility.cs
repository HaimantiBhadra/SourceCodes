﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MCCustomerService.Common
{
    public static class Utility
    {
        public static string logfile { get; set; }

        public static void WriteException(Exception exception)
        {

            try
            {

                if (File.Exists(logfile))
                {
                    using (var writer = new StreamWriter(logfile, true))
                    {
                        writer.WriteLine(
                            "=>{0} An Error occurred: {1}  Message: {2}{3}",
                            DateTime.Now,
                            exception.StackTrace,
                            exception.Message,
                            Environment.NewLine
                            );
                    }
                }
                else
                {
                    File.Create(logfile);
                    using (var writer = new StreamWriter(logfile, true))
                    {
                        writer.WriteLine(
                            "=>{0} An Error occurred: {1}  Message: {2}{3}",
                            DateTime.Now,
                            exception.StackTrace,
                            exception.Message,
                            Environment.NewLine
                            );
                    }
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }
    }


}
