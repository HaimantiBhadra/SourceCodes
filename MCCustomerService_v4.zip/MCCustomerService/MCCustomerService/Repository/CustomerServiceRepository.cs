﻿using MCCustomerService.Data;
using MCCustomerService.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MCCustomerService.Repository
{
    public class CustomerServiceRepository : ICustomerServiceRepository
    {
        private CustomerServiceContext customerDbContext;
        public CustomerServiceRepository(CustomerServiceContext _customerDbContext)
        {
            customerDbContext = _customerDbContext;
        }

        public Customer RetreiveCustomer(int id)
        {
            var cust = customerDbContext.Customer.SingleOrDefault(m => m.ID == id);
            return cust;
        }
        public void AddCustomer(Customer customer)
        {
            customerDbContext.Customer.Add(customer);
            customerDbContext.SaveChanges(true);
        }

        public void AddAccount(Account account)
        {
            customerDbContext.CustAccount.Add(account);
            customerDbContext.SaveChanges(true);
        }

        public void UpdateCustomer(Customer customer)
        {
            customerDbContext.Customer.Update(customer);
            customerDbContext.SaveChanges(true);
        }

    }
}
