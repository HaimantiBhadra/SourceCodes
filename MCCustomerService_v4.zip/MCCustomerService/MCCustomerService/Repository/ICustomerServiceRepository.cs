﻿using MCCustomerService.Models;

namespace MCCustomerService.Repository
{
    public interface ICustomerServiceRepository
    {
        Customer RetreiveCustomer(int id);
        void AddCustomer(Customer product);
        void UpdateCustomer(Customer product);

        void AddAccount(Account account);
    }
}