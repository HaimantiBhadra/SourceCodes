﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MCAccountService.Models
{
    [Serializable()]
    public class Accounts
    {
        [Key]
        public int AccountId { get; set; }
        public string AccountType { get; set; }
        public DateTime AccountOpeningDate { get; set; }
        public decimal CashBalance { get; set; }
        public int CustomerId { get; set; }
    }
}