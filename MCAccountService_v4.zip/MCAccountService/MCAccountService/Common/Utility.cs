﻿using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Protocols;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCAccountService.Common
{
    public static  class Utility
    {
        public static string logfile { get; set; }
        public static DataTable ToDataTable<T>(this IEnumerable<T> data)
        {
            PropertyDescriptorCollection properties =
                TypeDescriptor.GetProperties(typeof(T));

            DataTable table = new DataTable();
            
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }

        public static byte[] WriteCSVSimple(DataTable dtTable)
        {
            var output = new StringBuilder();

            for(int i= 0; i<dtTable.Columns.Count; i++)
            {
                DataColumn dataColumn = dtTable.Columns[i];
                output.Append("\"" + dataColumn.ColumnName + "\"");
                if (i < dtTable.Columns.Count - 1)
                    output.Append(",");
            }

            output.Append(Environment.NewLine);

            foreach(DataRow row in dtTable.Rows)
            {
                output.Append("\"" + string.Join("\",\"", row.ItemArray) + "\"");
                output.Append(Environment.NewLine);
            }

            ASCIIEncoding myEncoder = new ASCIIEncoding();
            byte[] data = myEncoder.GetBytes(output.ToString());

            return data;
        }


        public static void WriteException(Exception exception)
        {
           
            try
            {
                

                if (File.Exists(logfile))
                {
                    using (var writer = new StreamWriter(logfile, true))
                    {
                        writer.WriteLine(
                            "=>{0} An Error occurred: {1}  Message: {2}{3}",
                            DateTime.Now,
                            exception.StackTrace,
                            exception.Message,
                            Environment.NewLine
                            );
                    }
                }
                else
                {
                    File.Create(logfile);
                    using (var writer = new StreamWriter(logfile, true))
                    {
                        writer.WriteLine(
                            "=>{0} An Error occurred: {1}  Message: {2}{3}",
                            DateTime.Now,
                            exception.StackTrace,
                            exception.Message,
                            Environment.NewLine
                            );
                    }
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }
    }
}
