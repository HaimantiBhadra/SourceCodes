﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MCAccountService.Data;
using MCAccountService.Repository;
using MCAccountService.Models;
using System.Text;
using MCAccountService.Common;

namespace MCAccountService.Controllers
{
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        //private readonly AccountServiceContext _context;

        //public AccountsController(AccountServiceContext context)
        //{
        //    _context = context;
        //}

        private readonly IAccountServiceRepository accountsServicerepository;
        public AccountsController(IAccountServiceRepository accountsRepository)
        {
            accountsServicerepository = accountsRepository;
            
        }

        [HttpGet(Name = "CheckAccounts")]
        [Route("api/get")]
        public ActionResult<Accounts> RetriveAccounts(int accountId, int customerId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                Accounts Accounts = accountsServicerepository.RetreiveAccount(accountId, customerId);
                return Accounts;
                //return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            {
                Utility.WriteException(ex);
                return BadRequest(ex.Message); }
            //return CreatedAtAction("GetAccounts", new { id = Accounts.ID }, Accounts);
        }


        [HttpPost(Name = "AddAccounts")]
        [Route("api/add")]
        public ActionResult<Accounts> AddAccounts(Accounts accounts)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                accountsServicerepository.AddAccounts(accounts);
                return accounts;
                //return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            {
                Utility.WriteException(ex);
                return BadRequest(ex.Message); 
            }
            //return CreatedAtAction("GetAccounts", new { id = Accounts.ID }, Accounts);
        }

        [HttpPost(Name = "UpdateAccounts")]
        [Route("api/update")]
        public ActionResult<Accounts> UpdateAccounts(Accounts Accounts)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                accountsServicerepository.UpdateAccounts(Accounts);
                return Accounts;
                //return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            {
                Utility.WriteException(ex);
                return BadRequest(ex.Message); }
            //return CreatedAtAction("GetAccounts", new { id = Accounts.ID }, Accounts);
        }

        [HttpPost(Name = "ApplyLoan")]
        [Route("api/applyloan")]
        public ActionResult<LoanDetails> ApplyLoan(LoanDetails loanDetails)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                accountsServicerepository.ApplyLoan(loanDetails);
                return loanDetails;
                //return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            {
                Utility.WriteException(ex);
                return BadRequest(ex.Message); }
            //return CreatedAtAction("GetAccounts", new { id = Accounts.ID }, Accounts);
        }

        [HttpPost(Name = "DownloadAccountStatements")]
        [Route("api/download")]
        public FileResult DownloadAccountStatement(int customerId)
        {
            byte[] report = null;
            try
            {
                report = accountsServicerepository.DownloadAccountStatemenmt(customerId);
                //return File(report, "text/csv", customerId + "_AccountStatement.csv");
            }
            catch(Exception ex)
            {
                Utility.WriteException(ex);
                string noRecords = "No Records Found!!";
                // Convert a C# string to a byte array  
                report = Encoding.ASCII.GetBytes(noRecords);
                //return File(report, "text/csv", customerId + "_AccountStatement.csv");
            }

            return File(report, "text/csv", customerId + "_AccountStatement.csv");
        }

    }
}