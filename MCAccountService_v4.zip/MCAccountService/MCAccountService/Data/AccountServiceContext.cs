﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MCAccountService.Models;

namespace MCAccountService.Data
{
    public class AccountServiceContext : DbContext
    {
        public AccountServiceContext (DbContextOptions<AccountServiceContext> options)
            : base(options)
        {
        }

        
        public DbSet<Accounts> Accounts { get; set; }

        public DbSet<LoanDetails> AccountLoans { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Accounts>().ToTable("Accounts", "dbo");
            modelBuilder.Entity<LoanDetails>().ToTable("Loans", "dbo");

         }
    }
}
